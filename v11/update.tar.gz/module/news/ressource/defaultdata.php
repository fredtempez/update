<?php
class init extends search {
    public static $defaultData = [
        'feeds'              => false,
        'feedsLabel'         => '',
        'itemsperPage'       => 8,
        'itemsperCol'        => 12,
        'versionData'        => '3.2'
    ];
    public static $defaultTheme = [
        'itemsHeight'        => 'auto',
        'itemsBlur'         => '0%'
    ];
}